

	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.StreamTokenizer;
	import java.util.Scanner;

	public class kalkulator {

	public static void main(String[] args) {
		int wartosc = 0;
	    FileReader fr= null;
	    int a;
	    char wybor,znak = 0;
		int b;
		Scanner wej = new Scanner(System.in);
		 System.out.println("Program - kalkulator");
		 System.out.println("Prosze wybrac :");
		 System.out.println("k - jesli ma czytania z klawiatury");
		 System.out.println("c - jesli ma czytac z pliku");  
	     wybor = wej.next().charAt(0);
		    
		switch (wybor) {
		  case 'k':
		  {
				while( znak!='$'){
		    	 System.out.println("Podaj pierwsz� liczb�:"); // przy pomocy Scanner
		         a = wej.nextInt();
		         System.out.println("Podaj drug� liczb�:");
		         b = wej.nextInt();
		   
		         System.out.println("Dodawanie dw�ch liczb - wci�nij +");
		         System.out.println("Odejmowanie dw�ch liczb - wci�nij -");
		         System.out.println("Mno�enie dw�ch liczb - wci�nij *");
		         System.out.println("Dzielenie dw�ch liczb - wci�nij /");
		         System.out.println("Operacaja modulo - wci�nij %");
		         System.out.println("Koniec programu - wci�nij $");
		   
		         znak = wej.next().charAt(0);  // pobieramy symbol operacji od u�ytkownika
		         switch(znak)     // w zale�no�ci od wyboru wykonujemy dan� operacj�
		         {
		             case '+':    // dodawanie dw�ch zmiennych
		             {
		                 System.out.println(a + b);
		                 break;
		             }
		             case '-':    // odejmowanie dw�ch zmiennych
		             {
		                 System.out.println(a - b);
		                 break;
		             }
		             case '*':    // mno�enie dw�ch zmiennych
		             {
		                 System.out.println(a * b);
		                 break;
		             }
		             case '/':   // sprawdzenie, czy druga zmienna nie jest zerem oraz
		             {           // dzielenie dw�ch zmiennych 
		                 if(b !=0)
		                 {
		                   System.out.println(a / b + "oraz reszty: " +
		                           a % b);
		                 }
		                 else
		                 {
		                     System.out.println("Nie dzielimy przez zero!!!");
		                 }
		                 break;
		             }
		             case '%':  // jw. ale tym razem operacja modulo
		             {
		                 if(b !=0)  // r�wnie� sprawdzenie warunku dzielenia przez 0
		                 {
		                     System.out.println(a % b);
		                 }
		                 else
		                 {
		                     System.out.println("Nie dzielimy przez zero!!");
		                 }
		             }
		   
		         }
		    	}
			  break;
		    }

		  case 'c':
		    {
		    	try {
		            fr = new FileReader("plik.txt");
		         } catch (FileNotFoundException e) {
		               System.out.println("B��D PRZY OTWIERANIU PLIKU!");
		               System.exit(1);
		         }

		         StreamTokenizer st = new StreamTokenizer(fr);
		         //ODCZYT KOLEJNYCH "TOKEN�W" Z PLIKU:
		         try {
		            while( (wartosc = st.nextToken()) != StreamTokenizer.TT_EOF ){
		                  if(wartosc == StreamTokenizer.TT_WORD)
		                        System.out.println("Wczytano s�owo: "+ st.sval);
		                  else if(wartosc == StreamTokenizer.TT_NUMBER)  
		                        System.out.println("Wczytano liczb�: "+ st.nval);
		             }
		          } catch (IOException e) {
		                System.out.println("B��D ODCZYTU Z PLIKU!");
		                System.exit(2);
		          }

		          //ZAMYKANIE PLIKU:
		          try {
		             fr.close();
		          } catch (IOException e) {
		               System.out.println("B��D PRZY ZAMYKANIU PLIKU!");
		               System.exit(3);
		          }
		    	
			  break;
		    }

		  default:
		    {
		    	 System.out.println("Nie wybrales odpowiedniego numeru! ");
		    	 break;
		    }
		}
	}
	}


